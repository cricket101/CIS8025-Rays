package com.example.mycontactlist;

import java.util.ArrayList;

import com.example.mycontactlist.R.layout;

import android.app.Activity;
import android.app.ListActivity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.BatteryManager;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.Layout;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class ContactListActivity extends ListActivity {
	boolean isDeleting = false;
	ContactAdapter adapter;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_contact_list);
		initMapButton();
		//initListButton();
		initSettingsButton();
		printColor();
		initDeleteButton();
		initAddContactButton();
		
	/*	ContactDataSource ds = new ContactDataSource(this);
		ds.open();
		final ArrayList<String> contacts = ds.getContacts();
		ds.close();
		
		//setListAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, names));
		
		//setListAdapter( new ContactAdapter( this , contacts));
		
		adapter = new ContactAdapter( this,contacts);
		setListAdapter( adapter );
		
		ListView listView = getListView();
		listView.setOnItemClickListener( new AdapterView.OnItemClickListener()
		{
		@Override
		public void onItemClick(AdapterView<?> parent, View itemClicked, int position,long id) {
				Contact selectedContact = contacts.get(position); //2
				
				if ( isDeleting ) {
					adapter .showDelete(position, itemClicked, ContactListActivity. this ,selectedContact);
					}
					else {
					Intent intent = new Intent(ContactListActivity. this , ContactActivity. class );
					intent.putExtra( "contactid" , selectedContact.getContactID());
					startActivity(intent);
				
		}
		});*/
		
		BroadcastReceiver batteryReceiver = new BroadcastReceiver() {
			   @Override
			   public void onReceive(Context context, Intent intent) {
			       double batteryLevel= intent.getIntExtra(BatteryManager.EXTRA_LEVEL,0);
			       double levelScale= intent.getIntExtra(BatteryManager.EXTRA_SCALE,0);
			       int batteryPercent = (int) Math.floor(batteryLevel/levelScale*100);
			       TextView textBatteryState=(TextView) findViewById(R.id.textBatteryLevel);
			       textBatteryState.setText(batteryPercent+"%");	
			   }
			};

			IntentFilter filter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
			registerReceiver(batteryReceiver, filter);
		
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.contact_list, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
	
	private void initListButton(){
		ImageButton list = (ImageButton)
	findViewById(R.id.imageButtonList);
		list.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v){
				Intent intent = new Intent(ContactListActivity.this, 
	ContactListActivity.class);
				intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(intent);
			}
			
			
		});
		
	}

	private void initMapButton(){
		
		ImageButton list = (ImageButton)
	findViewById(R.id.imageButtonMap);
		list.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v){
				Intent intent = new Intent(ContactListActivity.this, 
	ContactMapActivity.class);
				intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(intent);
			}
			
			
		});
	}
	
	private void initSettingsButton(){
		ImageButton list = (ImageButton)
	findViewById(R.id.imageButtonSettings);
		list.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v){
				Intent intent = new Intent(ContactListActivity.this, 
	ContactSettingsActivity.class);
				intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(intent);
			}
			
			
		});
	}
	public void printColor(){
		String color = getSharedPreferences("MyContactListPreferences", Context.MODE_PRIVATE).getString("color", "Yellow");
			System.out.println(color);
		
			RelativeLayout Layout = (RelativeLayout) findViewById(R.layout.activity_contact_list);
	}
	
	//if (color == "Green"){
		//Layout.setBackgroundColor(Color.parseColor("#006400"));
	//}
	
	private void initDeleteButton() {
		final Button deleteButton = (Button) findViewById(R.id. buttonDelete );
		deleteButton.setOnClickListener( new OnClickListener() {
		public void onClick(View v) {
		if ( isDeleting ) {
		deleteButton.setText( "Delete" );
		isDeleting = false ;
		//1
		adapter .notifyDataSetChanged();
		}
		else {
		deleteButton.setText( "Done Deleting" );
		isDeleting = true ;
		}
		}
		});
		}
	
	public void onResume() {
		super.onResume();
		String sortBy = getSharedPreferences("MyContactListPreferences", Context.MODE_PRIVATE).getString("sortfield", "contactname");
		String sortOrder = getSharedPreferences("MyContactListPreferences", Context.MODE_PRIVATE).getString("sortorder", "ASC");

		ContactDataSource ds = new ContactDataSource(this);
		ds.open();
		final ArrayList<Contact> contacts = ds.getContacts(sortBy, sortOrder);
		ds.close();
		
		if (contacts.size() > 0) {

			adapter = new ContactAdapter(this, contacts);
			setListAdapter(adapter);
			ListView listView = getListView();
			listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

				@Override
				public void onItemClick(AdapterView<?> parent, View itemClicked,
						int position, long id) {
					Contact selectedContact = contacts.get(position);
					if (isDeleting) {
						adapter.showDelete(position, itemClicked, ContactListActivity.this, selectedContact);
					}
					else {
						Intent intent = new Intent(ContactListActivity.this, ContactActivity.class);
						intent.putExtra("contactid", selectedContact.getContactID());
						startActivity(intent);
					}
				}
			});
		}
		else {
			Intent intent = new Intent(ContactListActivity.this, ContactActivity.class);
			startActivity(intent);
		}
	}
	
	private void initAddContactButton() {
		Button newContact = (Button) findViewById(R.id.buttonAdd);
		newContact.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
    			Intent intent = new Intent(ContactListActivity.this, ContactActivity.class);
    			startActivity(intent);
            }
        });
	}
	
}
